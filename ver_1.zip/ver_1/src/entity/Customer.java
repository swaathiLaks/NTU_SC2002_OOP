package entity;
import java.util.Random; 
import java.util.List;

// Base customer
public abstract class Customer {
    private static final List<String> ORDER_CYCLE = List.of("Pasta", "Burger", "Salad");

    private final int id;
    // Starts full, drops while waiting
    private int satisfaction = 100;
    // New customers join the queue
    private CustomerState state = CustomerState.WAITING;
    // Null until the customer orders
    private Order order;
    private int servedTurn;
    private int readyToPayTurn;

    // id: unique customer number, starting from 1
    protected Customer(int id) { this.id = id; }

    // Satisfaction lost for each turn spent waiting for a table or food
    public abstract int waitingLoss();

    // Bill for an item with the given base price. Regular customers pay full price
    public int priceFor(int baseCents) { return baseCents; }

    public MenuItem chooseItem(Menu menu, Random rng) {
        List<MenuItem> items = menu.getItems();
        return items.get(rng.nextInt(items.size()));
    }

    // Applies one turn of waiting. Returns true if satisfaction has reached 0
    public boolean applyWaitingPenalty() {
        satisfaction = Math.max(0, satisfaction - waitingLoss());
        return satisfaction == 0;
    }

    // True while waiting for a table or for food: these customers lose satisfaction
    public boolean isWaitingForService() {
        return state == CustomerState.WAITING || state == CustomerState.SEATED || state == CustomerState.ORDERED;
    }

    // Marks the food as delivered and records the turn, so eating finishes next turn
    public void markServed(int turn) { state = CustomerState.SERVED; servedTurn = turn; }
    // Marks the customer as finished eating and records the turn, for oldest-first payment
    public void markReadyToPay(int turn) { state = CustomerState.READY_TO_PAY; readyToPayTurn = turn; }
    void markSeated()        { state = CustomerState.SEATED; }
    void markOrdered(Order o){ order = o; state = CustomerState.ORDERED; }
    void markPaid()          { state = CustomerState.PAID; }
    void markLeft()          { state = CustomerState.LEFT; }
    // Getters and setters
    public int getId() { return id; }
    public int getSatisfaction() { return satisfaction; }
    public CustomerState getState() { return state; }
    public void setOrder(Order o) { order = o; }
    public int getServedTurn() { return servedTurn; }
    public int getReadyToPayTurn() { return readyToPayTurn; }
    public Order getOrder() { return order;}
}